package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.QA;
import model.QACategory;


public class QAListDAO {
	// データベース接続に使用する情報
	private final String JDBC_URL = "jdbc:h2:tcp://localhost/~/jobridge";
	private final String DB_USER = "sa";
	private final String DB_PASS = "";
	
	public List<QA> findAll() {
		List<QA> qaList = new ArrayList<>();
		
		// JDBCドライバを読み込む
		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("JDBCドライバを読み込めませんでした");
		}
		
		// データベースに接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			
			// SELECT文を準備
			String sql = "SELECT q.QuestionContent, a.AnswerContent FROM Questions q LEFT JOIN Answers a ON q.QuestionID = a.QuestionID ORDER BY q.CategoryID ASC, q.QuestionID ASC";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			// SQL分を実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();
			
			// 結果表に格納されたレコードの内容をインスタンスに設定し、ArrayListインスタンスに追加
			while (rs.next()) {
				 String questionContent = rs.getString("QuestionContent");
				 String answerContent = rs.getString("AnswerContent");
				 QA qa = new QA(questionContent, answerContent);
				 qaList.add(qa);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return qaList;
	}
	
	
	public List<QA> findByKeyword(String keyword) {
		List<QA> qaList = new ArrayList<>();
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			// 検索キーワードを含む質問と回答を取得するSQLクエリ
			String sql = "SELECT q.QuestionContent, a.AnswerContent FROM Questions q LEFT JOIN Answers a ON q.QuestionID = a.QuestionID WHERE q.QuestionContent LIKE ? OR a.AnswerContent LIKE ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, "%" + keyword + "%");
			pStmt.setString(2, "%" + keyword + "%");
			
			// SQL分を実行し、結果表を取得
			ResultSet rs = pStmt.executeQuery();
			
			// 結果表に格納されたレコードの内容をインスタンスに設定し、ArrayListインスタンスに追加
			while (rs.next()) {
				String questionContent = rs.getString("QuestionContent");
				String answerContent = rs.getString("AnswerContent");
				QA qa = new QA(questionContent, answerContent);
				qaList.add(qa);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return qaList;
	}
	
	// カテゴリに関連付けされた質問と回答を紐づけるメソッドを追加
	public List<QA> findByCategoryId(int categoryId) {
		List<QA> qaList = new ArrayList<>();
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT q.QuestionContent, a.AnswerContent FROM Questions q LEFT JOIN Answers a ON q.QuestionID = a.QuestionID WHERE q.CategoryID = ? ORDER BY q.CategoryID ASC, q.QuestionID ASC";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, categoryId);
			ResultSet rs = pStmt.executeQuery();
			while (rs.next()) {
				String questionContent = rs.getString("QuestionContent");
				String answerContent = rs.getString("AnswerContent");
				QA qa = new QA(questionContent, answerContent);
				qaList.add(qa);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return qaList;
	}
	
	// 全てのカテゴリを取得するメソッドを追加
		public List<QACategory> findAllCategories() {
			List<QACategory> categoryList = new ArrayList<>();
			try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
				String sql = "SELECT CategoryID, CategoryName FROM Categories";
				PreparedStatement pStmt = conn.prepareStatement(sql);
				ResultSet rs = pStmt.executeQuery();
				
				while (rs.next()) {
					int categoryId = rs.getInt("CategoryID");
					String categoryName = rs.getString("CategoryName");
					QACategory category = new QACategory(categoryId, categoryName);
					categoryList.add(category);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return categoryList;
		}
}
