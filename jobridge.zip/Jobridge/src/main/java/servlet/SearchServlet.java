package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.QAListDAO;
import model.QA;
import model.QACategory;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータから検索キーワードを取得
		String keyword = request.getParameter("keyword");
		// カテゴリIDを取得
		String categoryId = request.getParameter("categoryId");
		
		QAListDAO dao = new QAListDAO();
		
		 // カテゴリリストを取得
		List<QACategory> categoryList = dao.findAllCategories();
		// カテゴリリストをリクエスト属性にセット
		request.setAttribute("categoryList", categoryList);
		
		List<QA> qaList;
		
		// 検索キーワードが指定されている場合
		if (keyword != null && !keyword.isEmpty()) {
			qaList = dao.findByKeyword(keyword);
		} else if (categoryId != null && !categoryId.isEmpty()) { // カテゴリIDが指定されている場合
			qaList = dao.findByCategoryId(Integer.parseInt(categoryId));
		} else { // 検索キーワードもカテゴリIDも指定されていない場合
			qaList = dao.findAll();
		}
		
		// 検索結果のログ出力
		System.out.println("検索結果: " + qaList);
		
		if (qaList.isEmpty()) {
			// 検索結果が空の場合はリクエスト属性にセットせずに、直接JSPにフォワード
			request.getRequestDispatcher("/noResult.jsp").forward(request, response);
		} else {
			// 検索結果をリクエスト属性にセット
			request.setAttribute("qaList", qaList);
			// 検索結果を表示するJSPにフォワード
			request.getRequestDispatcher("/qaList.jsp").forward(request, response);
		}
	}
}