package test;

import java.util.List;

import dao.QAListDAO;
import model.QA;


//modelとDAOが機能しているか、テスト用のクラスです


public class Test {
	public static void main(String[] args) {
		QAListDAO qalDAO = new QAListDAO();
		List<QA> qaList = qalDAO.findAll();

		for (QA qa : qaList) {
			System.out.println("質問：" + qa.getQuestionContent());
			System.out.println("回答：" + (qa.getAnswerContent() != null ? qa.getAnswerContent() : "なし"));
			System.out.println();
		}
	}
}


