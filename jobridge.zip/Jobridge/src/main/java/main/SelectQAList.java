package main;

import java.util.List;

import dao.QAListDAO;
import model.Questions;

public class SelectQAList {
	public static void main(String[] args) {
		QAListDAO qalDAO = new QAListDAO();
		List<Questions> qList = qalDAO.findAll();
		
		for (Questions q : qList) {
			System.out.println("質問：" + q.getQuestionContent());
			System.out.println();
			System.out.println();
		}
	}

}
