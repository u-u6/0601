package model;

public class Answers {
	private String answerId;
	private String questionId;
	private String answerContent;
	
	public Answers ( String answerId, String questionId,String answerContent) {
		this.answerId = answerId;
		this.questionId = questionId;
		this.answerContent = answerContent;
	}
	
	public String getAnswerId() { return answerId; }
	public String getQuestionId() { return questionId; }
	public String getQuestionerName() { return answerContent; }

}
