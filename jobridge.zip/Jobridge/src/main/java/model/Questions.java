package model;

public class Questions {
	private String questionId;
	private String categoryId;
	private String questionContent;

	public Questions(String questionId, String categoryId, String questionContent) {
		this.questionId = questionId;
		this.categoryId = categoryId;
		this.questionContent = questionContent;
	}
	public String getQuestionId() { return questionId; }
	public String getCategoryId() { return categoryId; }
	public String getQuestionContent() { return questionContent; }
	
}