package model;

public class QA {
	private String questionContent;
	private String answerContent;
	
	public QA(String questionContent, String answerContent) {
		this.questionContent = questionContent;
		this.answerContent = answerContent;
    }
	
	public String getQuestionContent() { return questionContent; }
	public String getAnswerContent() { return answerContent; }
}